# Relatório consolidado de segurança

## Identificação da execução

- Repositório: `DevJoaoVitorB/tcc-vibe-coding-security`
- Execução: `42736941358`
- Tentativa: `1`
- Commit: `10e81afba792a7e8779461c15d07b40daad61ce0`
- Tratamento experimental: `A`
- Data UTC: 2026-11-10 01:40:38

## Estado dos jobs

| Etapa | Resultado do GitHub Actions |
|---|---|
| Validação | success |
| SAST | success |
| SCA | success |
| DAST | success |

## SAST — Semgrep

| Métrica | Quantidade |
|---|---:|
| Achados reportados | 1 |
| Erros reportados pela ferramenta | 0 |

| Severidade original | Quantidade |
|---|---:|
| ERROR | 1 |

## SCA — npm audit

### sca-all-report.json

| Severidade original | Quantidade |
|---|---:|
| Critical | 2 |
| High | 4 |
| Moderate | 1 |
| Low | 0 |
| Info | 0 |
| Total reportado | 7 |

Dependências analisadas: 265

### sca-production-report.json

| Severidade original | Quantidade |
|---|---:|
| Critical | 0 |
| High | 4 |
| Moderate | 0 |
| Low | 0 |
| Info | 0 |
| Total reportado | 4 |

Dependências de produção analisadas: 120

## DAST — OWASP ZAP

| Severidade | Quantidade de ocorrências |
|---|---:|
| High | 0 |
| Medium | 0 |
| Low | 7 |
| Informational | 4 |
| Unknown | 0 |
| **Total** | **11** |

## Limitações e interpretação

- Os resultados representam achados reportados pelas ferramentas, não vulnerabilidades confirmadas individualmente.
- As severidades são mantidas conforme a classificação original de cada ferramenta.
- No SAST, os achados são contabilizados conforme os resultados presentes no JSON do Semgrep.
- No SCA, os totais são os reportados pelo npm audit. Os relatórios de todas as dependências e de produção possuem escopos distintos e não devem ser somados.
- No DAST, a tabela de severidade considera as ocorrências individuais presentes nas instâncias do relatório JSON original do ZAP.
- A varredura DAST não comprova, por si só, a cobertura de operações autenticadas ou de autorização entre usuários.
- A ausência de um relatório não significa ausência de vulnerabilidades.
- A existência de um relatório, isoladamente, não comprova que a análise foi concluída com sucesso.
- Os relatórios JSON originais são preservados para auditoria.
- Os totais de SAST, SCA e DAST não devem ser somados automaticamente.

## Relatórios JSON incluídos

- `dast-report.json`
- `sast-report.json`
- `sca-all-report.json`
- `sca-production-report.json`
